# Rbdash

A simple and stupid clone of [LoDash](https://npmjs.com/packages/lodash) in python.

This was made for my blog post on [dev.to](https://dev.to/arnu515/create-a-pypi-pip-package-test-it-and-publish-it-using-github-actions-21k3) and is not a serious package, so don't expect updates.